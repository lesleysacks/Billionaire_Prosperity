/**
 * Central content configuration.
 *
 * Every piece of business information shown on the site lives here, so the
 * client's details can be dropped in without touching page templates.
 *
 * Rules:
 * - Never invent business facts. Anything unknown stays as a `TODO: CLIENT TO PROVIDE`
 *   placeholder below.
 * - Placeholder values are detected by `isConfigured()` in `src/lib/contact.ts` and hidden
 *   from the visible UI until real values are supplied.
 */

// TODO: CLIENT TO PROVIDE WhatsApp number in international format, digits only (e.g. 27821234567).
export const WHATSAPP_NUMBER = "REPLACE_WITH_CLIENT_NUMBER";

// TODO: CLIENT TO PROVIDE a form service endpoint (e.g. Formspree, Basin, Getform, Netlify Forms).
// While empty, the contact form hands the enquiry off to WhatsApp / email / copy instead of posting.
export const FORM_ENDPOINT = "";

export const site = {
  // TODO: CLIENT TO PROVIDE final business name. The descriptive name below is used until then.
  name: "Private Transport & Tours",
  shortName: "Private Transport & Tours",
  tagline: "Cape Winelands",
  description:
    "Private transport and tours in Cape Town and the Cape Winelands — airport transfers, business travel, wine tours and personalised private journeys.",

  // TODO: CLIENT TO PROVIDE production domain (used for canonical URLs, Open Graph and sitemap).
  url: "https://example.com",
  locale: "en_ZA",

  // Service area as described in the brief. Do not add a street address or geo claims here.
  serviceArea: "Cape Town & the Cape Winelands",

  contact: {
    whatsapp: WHATSAPP_NUMBER,
    // TODO: CLIENT TO PROVIDE phone number in international format, e.g. "+27 00 000 0000".
    phone: "TODO: CLIENT TO PROVIDE PHONE",
    // TODO: CLIENT TO PROVIDE enquiries email address.
    email: "TODO: CLIENT TO PROVIDE EMAIL",
    // TODO: CLIENT TO PROVIDE business address (or leave as-is to keep it hidden).
    address: "TODO: CLIENT TO PROVIDE BUSINESS ADDRESS",
    whatsappGreeting: "Hello, I'd like to enquire about private transport.",
  },

  social: {
    // TODO: Add Instagram URL
    instagram: "",
    // TODO: Add Facebook URL
    facebook: "",
    // TODO: Add TikTok URL if applicable
    tiktok: "",
  },

  // TODO: CLIENT TO PROVIDE a default social sharing image (1200×630) at this path.
  ogImage: "/assets/images/hero/og-default.jpg",
} as const;

export const cta = {
  primary: "Book / Enquire",
  whatsapp: "WhatsApp Us",
  bookTransfer: "Book Your Transfer",
  bookJourney: "Book Your Journey",
  exploreWineTours: "Explore Wine Tours",
  planWineTour: "Plan Your Wine Tour",
  sendEnquiry: "Send Enquiry",
} as const;

export const nav = [
  { label: "Home", href: "/" },
  { label: "Services", href: "/services/" },
  { label: "Wine Tours", href: "/wine-tours/" },
  { label: "Fleet", href: "/fleet/" },
  { label: "About", href: "/about/" },
  { label: "Gallery", href: "/gallery/" },
  { label: "Contact", href: "/contact/" },
] as const;

export type ServiceKey = "airport-transfer" | "business-transport" | "wine-tour" | "private-tour";

export interface Service {
  key: ServiceKey;
  id: string;
  name: string;
  summary: string;
  description: string;
  points?: string[];
  image: string;
  imageAlt: string;
  cta: { label: string; href: string };
}

export const services: Service[] = [
  {
    key: "airport-transfer",
    id: "airport-transfers",
    name: "Airport Transfers",
    summary: "Private, unhurried transfers between the airport, your hotel and home.",
    description:
      "Private transportation to and from the airport, hotels, residences and other destinations.",
    image: "services/airport-transfer.jpg",
    imageAlt: "Private vehicle ready for an airport transfer",
    cta: { label: "Request a Transfer", href: "/contact/?service=airport-transfer" },
  },
  {
    key: "business-transport",
    id: "business-transport",
    name: "Business Transport",
    summary: "Discreet, punctual transport for meetings, events and visiting clients.",
    description:
      "Reliable private transport for the working day — getting you, your team or your guests where they need to be, on time and in comfort.",
    points: ["Meetings", "Corporate travel", "Events", "Client transport", "Executive travel"],
    image: "services/business-transport.jpg",
    imageAlt: "Business traveller being met by a private driver",
    cta: { label: "Enquire Now", href: "/contact/?service=business-transport" },
  },
  {
    key: "wine-tour",
    id: "wine-tours",
    name: "Wine Tours",
    summary: "Private days out through Stellenbosch, Franschhoek, Paarl and beyond.",
    description:
      "Relaxed, private wine days through the Cape Winelands, planned around the regions and pace you prefer.",
    points: ["Stellenbosch", "Franschhoek", "Paarl", "Custom wine tours"],
    image: "services/wine-tours.jpg",
    imageAlt: "Vineyards in the Cape Winelands",
    cta: { label: "Explore Wine Tours", href: "/wine-tours/" },
  },
  {
    key: "private-tour",
    id: "private-tours",
    name: "Private Tours",
    summary: "Personalised journeys around Cape Town and the Winelands, on your schedule.",
    description:
      "Personalised private travel shaped around you — tell us what you'd like to see and we'll help plan the day.",
    image: "services/private-tours.jpg",
    imageAlt: "Scenic Cape road on a private tour",
    cta: { label: "Plan a Private Tour", href: "/contact/?service=private-tour" },
  },
];

/** Options shown in the contact form's service select. */
export const enquiryServices = [
  { value: "airport-transfer", label: "Airport Transfer" },
  { value: "wine-tour", label: "Wine Tour" },
  { value: "business-transport", label: "Business Transport" },
  { value: "private-tour", label: "Private Tour" },
  { value: "other", label: "Other" },
] as const;

export const TO_BE_CONFIRMED = "To be confirmed";

export interface Vehicle {
  id: string;
  name: string;
  image: string;
  imageAlt: string;
  passengers: string;
  luggage: string;
  idealFor: string;
}

// TODO: Replace vehicle details after client confirmation.
export const fleet: Vehicle[] = [
  {
    id: "vehicle-01",
    // TODO: CLIENT TO PROVIDE vehicle make and model.
    name: "Vehicle 01",
    image: "fleet/vehicle-01.jpg",
    imageAlt: "Vehicle 01 from the private fleet",
    passengers: TO_BE_CONFIRMED,
    luggage: TO_BE_CONFIRMED,
    idealFor: TO_BE_CONFIRMED,
  },
  {
    id: "vehicle-02",
    // TODO: CLIENT TO PROVIDE vehicle make and model.
    name: "Vehicle 02",
    image: "fleet/vehicle-02.jpg",
    imageAlt: "Vehicle 02 from the private fleet",
    passengers: TO_BE_CONFIRMED,
    luggage: TO_BE_CONFIRMED,
    idealFor: TO_BE_CONFIRMED,
  },
  {
    id: "chevrolet-suv",
    name: "Chevrolet SUV",
    image: "fleet/chevrolet-suv.jpg",
    imageAlt: "Chevrolet SUV from the private fleet",
    passengers: TO_BE_CONFIRMED,
    luggage: TO_BE_CONFIRMED,
    idealFor: TO_BE_CONFIRMED,
  },
];

export const wineDestinations = [
  {
    id: "stellenbosch",
    name: "Stellenbosch",
    copy: "Oak-lined streets, mountain views and a wide choice of wine farms, all within easy reach of Cape Town.",
    image: "wine-tours/stellenbosch.jpg",
  },
  {
    id: "franschhoek",
    name: "Franschhoek",
    copy: "A valley town set against dramatic peaks — ideal for a slower day of tastings and long lunches.",
    image: "wine-tours/franschhoek.jpg",
  },
  {
    id: "paarl",
    name: "Paarl",
    copy: "Broad valleys and granite outcrops, with a relaxed pace that suits an unhurried private day.",
    image: "wine-tours/paarl.jpg",
  },
  {
    id: "custom",
    name: "Custom Wine Tour",
    copy: "Have particular estates or regions in mind? Tell us, and we'll plan the route around you.",
    image: "wine-tours/custom-tour.jpg",
  },
] as const;

// TODO: CLIENT TO PROVIDE descriptive alt text for each gallery photo once final images are supplied.
export const gallery = Array.from({ length: 9 }, (_, i) => {
  const n = String(i + 1).padStart(2, "0");
  return { src: `gallery/gallery-${n}.jpg`, alt: `Private transport and tours gallery image ${i + 1}` };
});
