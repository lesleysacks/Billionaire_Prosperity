import { site } from "../config/site";

/** True when a config value has been replaced with real client data. */
export function isConfigured(value: string | undefined | null): value is string {
  if (!value) return false;
  const v = value.trim();
  return v.length > 0 && !v.startsWith("TODO") && !v.startsWith("REPLACE_WITH");
}

export function whatsappDigits(): string | null {
  const raw = site.contact.whatsapp;
  if (!isConfigured(raw)) return null;
  const digits = raw.replace(/\D/g, "");
  return digits.length >= 8 ? digits : null;
}

/**
 * WhatsApp deep link. Until the client number is supplied this falls back to the
 * contact page so the CTA never points to a broken chat.
 */
export function whatsappHref(message: string = site.contact.whatsappGreeting): string {
  const digits = whatsappDigits();
  if (!digits) return "/contact/#whatsapp";
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}

export function isWhatsappExternal(): boolean {
  return whatsappDigits() !== null;
}

export function phoneHref(): string | null {
  const p = site.contact.phone;
  return isConfigured(p) ? `tel:${p.replace(/[^\d+]/g, "")}` : null;
}

export function emailHref(): string | null {
  const e = site.contact.email;
  return isConfigured(e) ? `mailto:${e}` : null;
}

export function socialLinks() {
  const entries = [
    { label: "Instagram", href: site.social.instagram },
    { label: "Facebook", href: site.social.facebook },
    { label: "TikTok", href: site.social.tiktok },
  ];
  return entries.filter((s) => isConfigured(s.href));
}
