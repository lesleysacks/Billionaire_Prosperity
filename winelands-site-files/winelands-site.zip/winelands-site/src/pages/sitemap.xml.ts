import type { APIRoute } from "astro";
import { nav, site } from "../config/site";

export const GET: APIRoute = () => {
  const urls = nav
    .map((item) => `  <url><loc>${new URL(item.href, site.url).href}</loc></url>`)
    .join("\n");
  const body = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
  return new Response(body, { headers: { "Content-Type": "application/xml; charset=utf-8" } });
};
