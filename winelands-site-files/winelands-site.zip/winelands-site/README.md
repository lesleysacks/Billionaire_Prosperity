# Private Transport & Tours — Cape Winelands

Static marketing and enquiry website for a premium private transport and tours business in Cape Town and the Cape Winelands, South Africa.

- **Static only.** No backend, database, accounts or booking engine. Visitors enquire by contact form, phone or WhatsApp.
- **No invented business facts.** Anything not yet supplied by the client is a `TODO: CLIENT TO PROVIDE` placeholder in one config file. Placeholders are hidden from the visible UI until they're filled in.

## Stack

- [Astro](https://astro.build) 7 with TypeScript (strict). Outputs plain static HTML with very little JavaScript: the mobile nav, scroll reveals and the contact form.
- Plain CSS with design tokens (`src/styles/global.css`) and component-scoped styles. No UI framework.
- Self-hosted fonts via Fontsource: Cormorant Garamond for headings and Inter for body text.
- ESLint (`eslint-plugin-astro` + `typescript-eslint`) and `astro check` for linting and type checks.

## Getting started

Requires Node.js 22.12 or newer.

```bash
npm install
npm run dev        # dev server on http://localhost:4391
npm run build      # static output in dist/
npm run preview    # serve the production build locally
npm run lint       # ESLint
npm run check      # Astro + TypeScript type checks
npm run validate   # lint + check + build
```

Deploy the `dist/` folder to any static host (Netlify, Vercel, Cloudflare Pages, S3, shared hosting).

## Project structure

```
public/
  assets/images/           # drop real photography here (see below)
  favicon.svg
src/
  config/site.ts           # ALL editable business info and copy data
  lib/contact.ts           # WhatsApp / phone / email link helpers
  layouts/BaseLayout.astro # <head>, SEO meta, header, footer, WhatsApp button
  components/
    Header.astro           # sticky nav, mobile menu, Book / Enquire CTA
    Footer.astro
    WhatsAppButton.astro   # persistent floating WhatsApp CTA
    SiteImage.astro        # image with automatic placeholder fallback
    PageHero.astro, CtaBand.astro, ServiceCard.astro, VehicleCard.astro, Icon.astro
  pages/
    index.astro            # Home
    services.astro
    wine-tours.astro
    fleet.astro
    about.astro
    gallery.astro
    contact.astro          # enquiry form + WhatsApp
    404.astro
    robots.txt.ts          # generated robots.txt
    sitemap.xml.ts         # generated sitemap.xml
```

## Editing content

Everything the client will want to change lives in **`src/config/site.ts`**: business name, WhatsApp number, phone, email, address, social links, site URL, CTA labels, services, fleet, wine destinations and gallery alt text.

- `WHATSAPP_NUMBER`: international format, digits only (e.g. `27821234567`). Until it's set, every WhatsApp button links to the contact page instead of a broken chat.
- `site.contact.phone`, `email`, `address`: shown in the footer and contact page only once they no longer start with `TODO`.
- `site.social`: each link appears in the footer only once it has a URL.
- `site.url`: the production domain. It's used for canonical URLs, Open Graph tags, `robots.txt` and `sitemap.xml`. **Set this before launch.**

## Image placeholder guide

Photos live in `public/assets/images/`. `SiteImage.astro` checks whether each file exists. If it doesn't, the component renders a styled placeholder showing `[ IMAGE PLACEHOLDER ]` and the exact path it expects. To add a real photo, save it under the matching filename. The dev server picks it up on reload; for production, run `npm run build` again.

| Folder | Filename | Used on | Suggested ratio |
| --- | --- | --- | --- |
| `hero/` | `hero-transport.jpg` | Home hero (full screen) | 16:9 landscape, ≥ 2400px wide |
| `hero/` | `og-default.jpg` | Social sharing image (optional) | 1200 × 630 |
| `services/` | `airport-transfer.jpg` | Home cards, Services | 4:5 / 5:4 |
| `services/` | `business-transport.jpg` | Home cards, Services | 4:5 / 5:4 |
| `services/` | `wine-tours.jpg` | Home cards, Services | 4:5 / 5:4 |
| `services/` | `private-tours.jpg` | Home cards, Services | 4:5 / 5:4 |
| `fleet/` | `vehicle-01.jpg` | Home, Fleet | 3:2 / 16:10 |
| `fleet/` | `vehicle-02.jpg` | Home, Fleet | 3:2 / 16:10 |
| `fleet/` | `chevrolet-suv.jpg` | Home, Fleet | 3:2 / 16:10 |
| `wine-tours/` | `winelands-hero.jpg` | Wine Tours hero (full screen) | 16:9 landscape |
| `wine-tours/` | `winelands-feature.jpg` | Home wine feature | 4:5 portrait |
| `wine-tours/` | `stellenbosch.jpg` | Wine Tours | 16:11 |
| `wine-tours/` | `franschhoek.jpg` | Wine Tours | 16:11 |
| `wine-tours/` | `paarl.jpg` | Wine Tours | 16:11 |
| `wine-tours/` | `custom-tour.jpg` | Wine Tours | 16:11 |
| `about/` | `about-business.jpg` | About hero | 16:9 landscape |
| `about/` | `about-driver.jpg` | About | 4:5 portrait |
| `gallery/` | `gallery-01.jpg` … `gallery-09.jpg` | Gallery (editorial grid) | mixed; images are cropped to fit |

Images are cropped with `object-fit: cover` inside fixed-ratio frames, so the layout never shifts. Export JPGs at around 2000px on the long edge (hero images up to about 2600px) and compress them (e.g. with Squoosh) to keep pages fast. Everything below the fold is lazy-loaded.

## Contact form

The form (`src/pages/contact.astro`) validates in the browser (name, phone/WhatsApp, service, email format, future travel date, whole-number passenger count), shows accessible inline errors and moves focus to the first problem.

There is no backend, so the form never pretends to store an enquiry:

- **Default (no form service configured):** on submit it builds a pre-filled enquiry and offers **Send via WhatsApp**, **Send via email** (only for channels that are configured) and **Copy enquiry**, and tells the visitor plainly that the message isn't sent until they send it.
- **With a form service:** set `FORM_ENDPOINT` in `src/config/site.ts` to a service endpoint such as Formspree (`https://formspree.io/f/xxxx`), Basin or Getform. The form then POSTs the fields as `FormData` with `Accept: application/json` and shows a real "sent" confirmation. If the request fails, it falls back to the WhatsApp/email/copy handoff. A hidden honeypot field (`company`) filters simple bots.

> TODO: CLIENT TO PROVIDE a form service account and endpoint (or confirm WhatsApp/email handoff only).

## SEO & accessibility

- Per-page `<title>`, meta description, canonical URL, Open Graph and Twitter tags (`BaseLayout.astro`). `og:image` is only emitted once `hero/og-default.jpg` exists.
- `robots.txt` and `sitemap.xml` are generated from `site.url` and the nav config.
- No address, geo coordinates or LocalBusiness schema are published until the client confirms them.
- Semantic landmarks, one `h1` per page, skip link, visible focus styles, labelled form fields, errors that don't rely on colour alone, and `prefers-reduced-motion` support.

## Client TODO list

Everything below is marked `TODO: CLIENT TO PROVIDE` (or `TODO:`) in `src/config/site.ts` unless noted.

- [ ] Final business name (currently the descriptive "Private Transport & Tours")
- [ ] WhatsApp number (`WHATSAPP_NUMBER`)
- [ ] Phone number
- [ ] Email address
- [ ] Business address (optional; stays hidden until provided)
- [ ] Production domain (`site.url`)
- [ ] Vehicle specifications: make/model for Vehicle 01 and 02, plus passenger capacity, luggage and "ideal for" for all three vehicles
- [ ] Company story (About page copy in `src/pages/about.astro`, marked with a TODO comment)
- [ ] Social links: Instagram, Facebook, TikTok (if applicable)
- [ ] Final photography for every file in the image guide above, plus descriptive gallery alt text
- [ ] Form service endpoint (`FORM_ENDPOINT`), or confirm WhatsApp/email handoff only
- [ ] Logo (the header currently uses a simple monogram mark and the business name)
